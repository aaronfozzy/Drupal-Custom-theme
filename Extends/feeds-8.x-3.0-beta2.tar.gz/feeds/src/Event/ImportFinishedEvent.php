<?php

namespace Drupal\feeds\Event;

/**
 * Fired after an import has finished.
 */
class ImportFinishedEvent extends EventBase {}
