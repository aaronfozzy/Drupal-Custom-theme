<?php

namespace Drupal\feeds\Exception;

/**
 * Thrown if a referenced entity is not found.
 */
class ReferenceNotFoundException extends ValidationException {}
