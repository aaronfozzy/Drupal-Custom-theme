<?php

namespace Drupal\feeds\Exception;

/**
 * Thrown when a FeedsTarget is missing.
 */
class MissingTargetException extends FeedsRuntimeException {}
