<?php

namespace Drupal\feeds\Exception;

/**
 * Thrown if an access check fails.
 */
class EntityAccessException extends FeedsRuntimeException {}
