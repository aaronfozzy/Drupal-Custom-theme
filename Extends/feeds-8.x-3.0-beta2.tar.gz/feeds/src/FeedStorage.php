<?php

namespace Drupal\feeds;

use Drupal\Core\Entity\Sql\SqlContentEntityStorage;

/**
 * Controller class for Feed entities.
 */
class FeedStorage extends SqlContentEntityStorage implements FeedStorageInterface {

}
